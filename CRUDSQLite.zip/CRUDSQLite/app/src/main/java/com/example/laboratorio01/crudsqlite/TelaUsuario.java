package com.example.laboratorio01.crudsqlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.laboratorio01.crudsqlite.usuario.UsuarioDAO;

public class TelaUsuario extends AppCompatActivity {

    UsuarioDAO usuarioDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_usuario);

        usuarioDAO = new UsuarioDAO(openOrCreateDatabase(usuarioDAO.NOME_BANCO, MODE_PRIVATE, null));
    }
}
